from __future__ import print_function # Python 2/3 compatibility
import boto3
from botocore.exceptions import ClientError
import json
import decimal

# Helper class to convert a DynamoDB item to JSON.
class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            if abs(o) % 1 > 0:
                return float(o)
            else:
                return int(o)
        return super(DecimalEncoder, self).default(o)

#this file uses the reportCounter table
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('ridCounter')

def getRID():
    try:
        response = table.get_item(
            Key={
                'counterName':'master'
            })
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        item = response['Item']
        print(item)
        print()
        #we need to update the global rid count here, after 
        print(updateRID())
        return int(item['ridCount'])

def updateRID():
    #get user data from table
    response = table.update_item(
        Key={'counterName': 'master'},
        UpdateExpression="set ridCount = ridCount + :val",
        ExpressionAttributeValues={
            ':val': decimal.Decimal(1)
        },
        ReturnValues="UPDATED_NEW"
    )

    print("UpdateItem succeeded")
    print(json.dumps(response, indent=4, cls=DecimalEncoder))

    return "Updated Global ReportID count."
