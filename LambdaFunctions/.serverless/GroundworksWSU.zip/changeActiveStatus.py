from __future__ import print_function # Python 2/3 compatibility
import boto3
from botocore.exceptions import ClientError
import json
import decimal

# Helper class to convert a DynamoDB item to JSON.
class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            if abs(o) % 1 > 0:
                return float(o)
            else:
                return int(o)
        return super(DecimalEncoder, self).default(o)

def reportStatusHandler(event, context):
    try:
        if event['status'] == "active" or event['status'] == "ignored" or event['status'] == "completed" or event['status'] == "in progress":
            print(toggleStatus(event['reportID'], event['status']))
            return "Successfully updated ReportID " + event['reportID'] + " to have status " + event['status'] + "."
        else:
            return "Invalid status."
    except:
        return "ReportID not found."

def toggleStatus(reportID, status):
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('Reports')
    try:
        response = table.get_item(Key={
            'reportID': int(reportID)
            })
    except ClientError as e:
        return e.response['Error']['Message']
    item = response['Item']
    #here are the updates
    item['currentStatus'] = status
    #end of updates
    putResponse = table.put_item(Item=item)
    print("Sucessfully updated report.")



x = reportStatusHandler({"status":"ignored", "reportID":"8"}, "")

print(x)
