#my solutions for lab 8


while(1):
	programSelect = input("Which program would you like to test (t1-t4): ")


	if programSelect == "t1":
		def join(title, sep=" "):
			finalString = ""
			for s in title:
				finalString += (s + sep)
			return finalString - sep
