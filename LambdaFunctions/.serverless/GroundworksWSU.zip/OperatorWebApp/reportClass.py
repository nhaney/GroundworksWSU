#this class will take json and convert it into a report
class Report:
	def __init__(self, jsonData):
		self.__dict__ = json.loads(jsonData)

