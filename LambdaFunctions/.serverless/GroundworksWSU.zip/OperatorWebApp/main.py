from flask import Flask, request, render_template
import requests
from parseReports import parseReports
import json

app = Flask(__name__)

#Decoraters display different pages
@app.route('/')
def index():
	return render_template("index.html")

#this is for the map view
@app.route('/mapView')
def mapView():
	return "<h2>This is where map will go</h2>"

#this is for each individual report
@app.route('/reports/<int:rid>')
def show_report(rid):
	data = get_data("https://t5en5tbiv8.execute-api.us-west-2.amazonaws.com/beta/getreports?rid=" + str(rid))
	ridJson = json.loads(data)
	# specify different address and coordinates here.
	return render_template("rid.html", json=ridJson)

#this is where the table will be specified
@app.route('/table')
def table():
	text = request.args.get('jsdata')
	print(text)
	jsonList = []
	if text:
		data = get_data(" https://t5en5tbiv8.execute-api.us-west-2.amazonaws.com/beta/getreports")
		jsonList = parseReports(data)

	return render_template('table.html', reportList=jsonList)


if __name__ == '__main__':
	app.run(debug=True)


def get_data(url):
    return requests.get(url).json()
