function changeStatus(status){
	//Here we will send an http request to the server
	
}

