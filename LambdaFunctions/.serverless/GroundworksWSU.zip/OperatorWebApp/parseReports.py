import json
from reportClass import Report

def parseReports(jsonReport):
	'''
	This function takes the entire report and outputs
	a string of report objects
	'''
	d = {}
	returnList = []

	d = json.loads(jsonReport)
	
	for report in d['Items']:
		returnList.append(report)

	# we could sort this return list here, so 
	# reports are in order in the table.
	print(returnList)

	return returnList

